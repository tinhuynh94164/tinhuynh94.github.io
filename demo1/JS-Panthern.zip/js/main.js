$(document).ready(function(e) {
	wSilder.main.top();
});